create table `mtncard100` (
`mid` int(30) auto_increment,
`cardpin` text not null,
`ccamount` text not null,
`ccnet` text not null,
primary key(`mid`)
)
engine=myisam character set utf8 collate=utf8_general_ci;