create table `bal` (

`balid` int(30) auto_increment,
`carrier` text not null,
`ccpin` text not null,
`ccphone` text not null,
`ccpinam` text not null,
`status` text not null,
`accept` text not null,
`cctime` timestamp not null,
primary key(`balid`)



)
engine=myisam character set utf8 collate=utf8_general_ci;