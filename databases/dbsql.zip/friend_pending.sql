create table `friend_pending` (

`frid` int(30) auto_increment,
`fromuser` text not null,
`touser` text not null,
primary key(`frid`)
)
engine=myisam character set utf8 collate=utf8_general_ci;