create table `rplfile` (
`mid1` int(30) auto_increment,
`mid` text not null,
`cardpin` text not null,
`ccamount` text not null,
`ccnet` text not null,
`ccphone` text not null,
`tbl` text not null,
primary key(`mid1`)
)
engine=myisam character set utf8 collate=utf8_general_ci;