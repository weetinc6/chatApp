create table `bal1` (

`balid` int(30) auto_increment,
`bal` text not null,
`ccphone` text not null,

primary key(`balid`)



)
engine=myisam character set utf8 collate=utf8_general_ci;