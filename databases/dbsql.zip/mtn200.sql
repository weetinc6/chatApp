create table `mtncard200` (
`mid` int(30) auto_increment,
`cardpin` text not null,
`ccphone` text not null,
`ccstatus` text not null,
primary key(`mid`)
)
engine=myisam character set utf8 collate=utf8_general_ci;